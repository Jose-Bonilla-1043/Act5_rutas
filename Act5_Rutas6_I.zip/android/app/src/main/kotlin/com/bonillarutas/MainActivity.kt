package com.bonillarutas

import io.flutter.embedding.android.FlutterActivity

class MainActivity : FlutterActivity()
